import * as React from 'react';
import { GameState, Theme } from '../../types';
import { themes } from '../../themes';
import { useTranslation } from '../../i18n/LanguageContext';

export const AnswerFeedbackModal: React.FC<{ result: GameState['answerResult']; onClear: () => void; themeConfig: typeof themes[Theme] }> = ({ result, onClear, themeConfig }) => {
    const { t } = useTranslation();
    
    // FIX: Removed the internal timer to prevent race conditions with the game logic.
    // The parent component now controls when this modal is cleared.

    if (!result) return null;
    
    const { isCorrect, correctAnswer } = result;
    const animationClass = isCorrect ? 'animate-flash-green' : 'animate-shake';
    
    return (
        <div className={`fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4 animate-fade-in`}>
            <div className={`p-8 rounded-lg text-center w-full max-w-md border-4 ${isCorrect ? 'border-green-500 bg-green-500/10' : 'border-red-500 bg-red-500/10'} ${animationClass}`}>
                <h2 className={`text-5xl font-bold mb-4 ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                    {isCorrect ? t('correct') : t('incorrect')}
                </h2>
                {!isCorrect && (
                    <p className="text-xl text-gray-300">{t('correctAnswerWas', '')} <span className={`font-bold ${themeConfig.accentTextLight}`}>{correctAnswer}</span></p>
                )}
            </div>
        </div>
    );
};